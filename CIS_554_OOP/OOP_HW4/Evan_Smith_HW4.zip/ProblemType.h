#pragma once

enum class ProblemType
{
	Addition=1, Subtraction=2, Multiplication=3, Division=4, GrabBag=5
};