/*
Evan Smith
CIS 554 - M401 Object Oriented Programming in C++
Syracuse University
HW 6 : SavingsAccount
3/8/21
The main program for testing the SavingsAccount class
*/

#include <iostream>
#include "SavingsAccount.h"

using std::cout;

static double accountBalance1 = 2000;
static double accountBalance2 = 3000;

int main()
{
	cout << "Welcome to the SavingsAccount testing program!\n\n";

	SavingsAccount saver1(accountBalance1), saver2(accountBalance2);

	cout << "Account 1 starting balance: " << accountBalance1 << "\nAccount 2 starting balance: " << accountBalance2 << "\n\n";


	//set initial interest rate and calculate the first month
	double interestRate = 0.03;
	
	cout << "Setting interest rate to " << interestRate << "\n";
	SavingsAccount::modifyInterestRate(interestRate);

	saver1.calculateMonthlyInterest();
	saver2.calculateMonthlyInterest();

	cout << "Account Balances After One Month:\nAccount 1: " << saver1.getSavingsBalance() 
		<< "\nAccount 2: " << saver2.getSavingsBalance();


	//change interest rate and calculate another month
	interestRate = 0.04;

	cout << "\n\nSetting interest rate to " << interestRate << "\n";
	SavingsAccount::modifyInterestRate(interestRate);

	saver1.calculateMonthlyInterest();
	saver2.calculateMonthlyInterest();

	cout << "Account Balances After Two Months:\nAccount 1: " << saver1.getSavingsBalance()
		<< "\nAccount 2: " << saver2.getSavingsBalance() << "\n\n";
}