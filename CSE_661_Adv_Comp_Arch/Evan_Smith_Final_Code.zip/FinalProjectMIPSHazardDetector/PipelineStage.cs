﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FinalProjectMIPSHazardDetector
{
    public enum PipelineStage
    {
        None, F, D, X, M, W, Complete
    }
}
