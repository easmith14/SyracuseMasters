﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FinalProjectMIPSHazardDetector
{
    public enum RegisterType
    {
        Read, Written
    }
}
