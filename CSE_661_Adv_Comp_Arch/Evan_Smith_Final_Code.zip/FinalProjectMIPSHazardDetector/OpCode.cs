﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FinalProjectMIPSHazardDetector
{
    public enum OpCode
    {
        ADD, SUB, LDW, SVW
    }
}
